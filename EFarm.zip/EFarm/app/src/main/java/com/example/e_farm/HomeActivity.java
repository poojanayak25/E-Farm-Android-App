package com.example.e_farm;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class HomeActivity extends AppCompatActivity {

    private Button btn_buyer;
    private Button btn_seller;






    //card viewer
    CardView home;
    CardView profile;
    CardView help;
    CardView settings;
    CardView logout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        btn_buyer = (Button) findViewById(R.id.btn_buyer);




        btn_buyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity.this,BuyerPage.class);
                startActivity(categoryIntent);
                finish();
            }
        });

        btn_seller = (Button) findViewById(R.id.btn_seller);

        btn_seller.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity.this,SellerPage.class);
                startActivity(categoryIntent);
                finish();
            }
        });

        btn_buyer= (Button) findViewById(R.id.btn_buyer);

        btn_buyer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(HomeActivity.this,BuyerPage.class);
                startActivity(categoryIntent);
                finish();
            }
        });


        home = findViewById(R.id.home);
        profile = findViewById(R.id.profile);
        help = findViewById(R.id.help);
        settings = findViewById(R.id.settings);
        logout = findViewById(R.id.logout);
    }

    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        startActivity(new Intent(getApplicationContext(),SigninActivity.class));
        finish();










    }
}