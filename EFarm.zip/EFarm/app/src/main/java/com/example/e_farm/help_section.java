package com.example.e_farm;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class help_section extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help_section);
    }
}