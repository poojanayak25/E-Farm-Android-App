package com.example.e_farm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class BuyerPage extends AppCompatActivity {

    Button buyer_homebtn;
    Button buyer_searchbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buyer_page);

        buyer_homebtn = findViewById(R.id.buyer_homebtn);
        buyer_searchbtn = findViewById(R.id.buyer_searchbtn);


        buyer_homebtn = (Button) findViewById(R.id.buyer_homebtn);

        buyer_homebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(BuyerPage.this,HomeActivity.class);
                startActivity(categoryIntent);
                finish();
            }
        });


    }
}