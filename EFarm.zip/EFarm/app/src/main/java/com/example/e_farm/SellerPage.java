package com.example.e_farm;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.HashMap;

public class SellerPage extends AppCompatActivity {


    private Button back_btn;
    private Button addproduct;
    private ImageView addphoto;
    private EditText tittle, product_decp, quantity, price;




    private FirebaseDatabase db = FirebaseDatabase.getInstance();
    private DatabaseReference root1 = db.getReference().child("Product deails");

    private DatabaseReference root = FirebaseDatabase.getInstance().getReference();
    private StorageReference reference = FirebaseStorage.getInstance().getReference("Product deails");
    private Uri imageUri;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_page);

        addproduct = findViewById(R.id.addproduct);
        addphoto = (ImageView) findViewById(R.id.addphoto);
        back_btn = (Button) findViewById(R.id.back_btn);
        tittle = findViewById(R.id.tittle);
        product_decp = findViewById(R.id.product_decp);
        quantity = findViewById(R.id.quantity);
        price = findViewById(R.id.price);






        back_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent categoryIntent = new Intent(SellerPage.this,HomeActivity.class);
                startActivity(categoryIntent);
                finish();
            }
        });


       addphoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent galleryIntent = new Intent();
                galleryIntent.setAction(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
                startActivityForResult(galleryIntent, 2);

            }
        });


        addproduct.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (imageUri != null){
                    uploadToFirebase(imageUri);
                }else{


                    Toast.makeText(SellerPage.this, "Please Select Image", Toast.LENGTH_SHORT).show();
                }

                String stittle = tittle.getText().toString();
                String sproduct_decp = product_decp .getText().toString();
                String squantity = quantity.getText().toString();
                String sprice = price.getText().toString();

                HashMap<String, String> userMap = new HashMap<>();


                userMap.put("tittle", stittle);
                userMap.put("product_decp", sproduct_decp);
                userMap.put("quantity", squantity);
                userMap.put("price", sprice);

                root1.push().setValue(userMap);



            }



        });



        /*new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent homeIntent = new Intent(.this, SigninActivity.class);
                startActivity(homeIntent);
                finish();
            }
        }, SPLASH_TIME_OUT);*///


    }






    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode ==2 && resultCode == RESULT_OK && data != null){

            imageUri = data.getData();
            addphoto.setImageURI(imageUri);

        }
    }

    private void uploadToFirebase(Uri uri){

        final StorageReference fileRef = reference.child(System.currentTimeMillis() + "Product deails" + getFileExtension(uri));
        fileRef.putFile(uri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                fileRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {

                        Model model = new Model(uri.toString());
                        String modelId = root1.push().getKey();
                        root1.child(modelId).setValue(model);
                        Toast.makeText(SellerPage.this, "Uploaded Successfully", Toast.LENGTH_SHORT).show();

                        addphoto.setImageResource(R.drawable.ic_add_shopping_cart_24);
                    }
                });
            }
        }).addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onProgress(@NonNull UploadTask.TaskSnapshot snapshot) {

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(SellerPage.this, "Uploading Failed !!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private String getFileExtension(Uri mUri){

        ContentResolver cr = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(cr.getType(mUri));
    }
}