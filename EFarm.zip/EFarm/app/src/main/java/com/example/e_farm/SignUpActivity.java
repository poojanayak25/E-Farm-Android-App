package com.example.e_farm;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import org.w3c.dom.Text;

public class SignUpActivity extends AppCompatActivity {
    Button btn_register2;
    EditText username,E_email,mobile_no,address,aadhaarno,birthdate,password1,confirmpassword;
    TextView gender;
    FirebaseAuth mAuth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        username = findViewById(R.id.username);
        E_email = findViewById(R.id.E_email);
        mobile_no = findViewById(R.id.mobile_no);
        address = findViewById(R.id.address);
        aadhaarno = findViewById(R.id.aadhaarno);
        birthdate = findViewById(R.id.birthdate);
        password1 = findViewById(R.id.password1);
        confirmpassword = findViewById(R.id.confirmpassword);
        gender = findViewById(R.id.gender);
        btn_register2 = findViewById(R.id.btn_register2);


        mAuth = FirebaseAuth.getInstance();

        if (mAuth.getCurrentUser() != null){
            startActivity(new Intent(getApplicationContext(),MainActivity.class));
            finish();
        }


        btn_register2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = E_email.getText().toString().trim();
                String password = password1.getText().toString().trim();

                if (TextUtils.isEmpty(email)){
                    password1.setError("Email is Required");
                    return;
                }
                if (TextUtils.isEmpty(password)){
                    password1.setError("Password is Required");
                    return;
                }

                if (password.length() < 6){
                    password1.setError("Password must be more then 6 character");
                    return;
                }


                mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()){
                            Toast.makeText(SignUpActivity.this,"User Created", Toast.LENGTH_SHORT).show();
                           startActivity(new Intent(getApplicationContext(),MainActivity.class));
                        }
                        else {
                            Toast.makeText(SignUpActivity.this,"Error  !" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
            }
        });


    }
}