package com.example.e_farm;

public class UserHelperClass {
    String Tittle, Product_decp, Quantity, Price;

    public UserHelperClass() {
    }

    public UserHelperClass(String tittle, String product_decp, String quantity, String price) {
        this.Tittle = tittle;
        this.Product_decp = product_decp;
        this.Quantity = quantity;
        this.Price = price;
    }

    public String getTittle() {
        return Tittle;
    }

    public void setTittle(String tittle) {
        tittle = tittle;
    }

    public String getProduct_decp() {
        return Product_decp;
    }

    public void setProduct_decp(String product_decp) {
        Product_decp = product_decp;
    }

    public String getQuantity() {
        return Quantity;
    }

    public void setQuantity(String quantity) {
        Quantity = quantity;
    }

    public String getPrice() {
        return Price;
    }

    public void setPrice(String price) {
        Price = price;
    }
}
